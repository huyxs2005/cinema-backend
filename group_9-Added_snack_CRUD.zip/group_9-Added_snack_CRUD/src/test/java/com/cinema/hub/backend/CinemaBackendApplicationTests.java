package com.cinema.hub.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinemaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
