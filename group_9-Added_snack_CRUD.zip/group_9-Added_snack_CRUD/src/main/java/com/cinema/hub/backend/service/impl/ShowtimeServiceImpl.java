package com.cinema.hub.backend.service.impl;

import com.cinema.hub.backend.dto.common.PageResponse;
import com.cinema.hub.backend.dto.showtime.ShowtimeRequest;
import com.cinema.hub.backend.dto.showtime.ShowtimeResponse;
import com.cinema.hub.backend.entity.Auditorium;
import com.cinema.hub.backend.entity.Movie;
import com.cinema.hub.backend.entity.Seat;
import com.cinema.hub.backend.entity.Showtime;
import com.cinema.hub.backend.entity.ShowtimeSeat;
import com.cinema.hub.backend.mapper.ShowtimeMapper;
import com.cinema.hub.backend.repository.AuditoriumRepository;
import com.cinema.hub.backend.repository.MovieRepository;
import com.cinema.hub.backend.repository.SeatRepository;
import com.cinema.hub.backend.repository.ShowtimeRepository;
import com.cinema.hub.backend.repository.ShowtimeSeatRepository;
import com.cinema.hub.backend.service.ShowtimeService;
import com.cinema.hub.backend.specification.ShowtimeSpecifications;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
@RequiredArgsConstructor
@Transactional
public class ShowtimeServiceImpl implements ShowtimeService {

    private static final String DEFAULT_SEAT_STATUS = "Available";
    private static final int DEFAULT_CLEANUP_MINUTES = 15;
    private static final BigDecimal WEEKDAY_MORNING_PRICE = new BigDecimal("55000");
    private static final BigDecimal WEEKDAY_AFTERNOON_PRICE = new BigDecimal("70000");
    private static final BigDecimal WEEKDAY_EVENING_PRICE = new BigDecimal("80000");
    private static final BigDecimal WEEKDAY_LATE_PRICE = new BigDecimal("65000");
    private static final BigDecimal WEEKEND_MORNING_PRICE = new BigDecimal("65000");
    private static final BigDecimal WEEKEND_AFTERNOON_PRICE = new BigDecimal("75000");
    private static final BigDecimal WEEKEND_EVENING_PRICE = new BigDecimal("90000");
    private static final BigDecimal WEEKEND_LATE_PRICE = new BigDecimal("80000");

    private final ShowtimeRepository showtimeRepository;
    private final MovieRepository movieRepository;
    private final AuditoriumRepository auditoriumRepository;
    private final SeatRepository seatRepository;
    private final ShowtimeSeatRepository showtimeSeatRepository;
    private final ShowtimeMapper showtimeMapper;

    @Override
    public List<ShowtimeResponse> create(ShowtimeRequest request) {
        Movie movie = requireMovie(request.getMovieId());
        Auditorium auditorium = requireAuditorium(request.getAuditoriumId());
        List<ScheduleSlot> slots = buildScheduleSlots(movie, request);
        slots.forEach(slot -> enforceNoConflict(auditorium.getId(), slot.start(), slot.end(), null));

        List<ShowtimeResponse> responses = new ArrayList<>();
        for (ScheduleSlot slot : slots) {
            Showtime showtime = new Showtime();
            showtime.setMovie(movie);
            showtime.setAuditorium(auditorium);
            showtime.setStartTime(slot.start());
            showtime.setEndTime(slot.end());
            showtime.setBasePrice(determineBasePrice(slot.start()));
            showtime.setActive(Boolean.TRUE.equals(request.getActive()));
            Showtime saved = showtimeRepository.save(showtime);
            generateShowtimeSeats(saved);
            responses.add(showtimeMapper.toResponse(saved));
        }
        return responses;
    }

    @Override
    public ShowtimeResponse update(int id, ShowtimeRequest request) {
        Showtime showtime = getEntity(id);
        Movie movie = requireMovie(request.getMovieId());
        Auditorium auditorium = requireAuditorium(request.getAuditoriumId());
        LocalDateTime endTime = calculateEndTime(movie, request.getStartTime(), request.getCleanupMinutes());
        enforceNoConflict(auditorium.getId(), request.getStartTime(), endTime, id);

        showtime.setMovie(movie);
        showtime.setAuditorium(auditorium);
        showtime.setStartTime(request.getStartTime());
        showtime.setEndTime(endTime);
        showtime.setBasePrice(determineBasePrice(request.getStartTime()));
        showtime.setActive(request.getActive());
        return showtimeMapper.toResponse(showtimeRepository.save(showtime));
    }

    @Override
    @Transactional(readOnly = true)
    public ShowtimeResponse get(int id) {
        return showtimeMapper.toResponse(getEntity(id));
    }

    @Override
    public void deactivate(int id) {
        Showtime showtime = getEntity(id);
        showtime.setActive(Boolean.FALSE);
        showtimeRepository.save(showtime);
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponse<ShowtimeResponse> search(Integer movieId,
                                                 Integer auditoriumId,
                                                 Boolean active,
                                                 LocalDate fromDate,
                                                 LocalDate toDate,
                                                 String keyword,
                                                 Pageable pageable) {
        Page<Showtime> page = showtimeRepository.findAll(
                ShowtimeSpecifications.filter(movieId, auditoriumId, active, fromDate, toDate, keyword), pageable);
        return PageResponse.from(page.map(showtimeMapper::toResponse));
    }

    private Movie requireMovie(Integer id) {
        return movieRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Movie not found: " + id));
    }

    private Auditorium requireAuditorium(Integer id) {
        return auditoriumRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Auditorium not found: " + id));
    }

    private Showtime getEntity(int id) {
        return showtimeRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Showtime not found: " + id));
    }

    private LocalDateTime calculateEndTime(Movie movie, LocalDateTime startTime, Integer cleanupMinutes) {
        if (startTime == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Start time is required");
        }
        int duration = movie.getDurationMinutes() != null ? movie.getDurationMinutes() : 0;
        int cleanup = cleanupMinutes != null ? cleanupMinutes : DEFAULT_CLEANUP_MINUTES;
        LocalDateTime endTime = startTime.plusMinutes(duration + Math.max(cleanup, 0));
        if (!endTime.isAfter(startTime)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "End time must be after start time");
        }
        return endTime;
    }

    private void enforceNoConflict(Integer auditoriumId,
                                   LocalDateTime start,
                                   LocalDateTime end,
                                   Integer excludeId) {
        boolean conflict = showtimeRepository.existsConflictingShowtime(auditoriumId, start, end, excludeId);
        if (conflict) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Phòng chiếu đã có suất chiếu khác trong khoảng thời gian này.");
        }
    }

    private void generateShowtimeSeats(Showtime showtime) {
        List<Seat> seats = seatRepository
                .findByAuditorium_IdAndActiveTrueOrderByRowLabelAscSeatNumberAsc(showtime.getAuditorium().getId());
        if (seats.isEmpty()) {
            return;
        }
        BigDecimal basePrice = showtime.getBasePrice();
        List<ShowtimeSeat> seatSnapshots = seats.stream()
                .map(seat -> ShowtimeSeat.builder()
                        .showtime(showtime)
                        .seat(seat)
                        .effectivePrice(calculateSeatPrice(basePrice,
                                seat.getSeatType() != null ? seat.getSeatType().getPriceMultiplier() : null))
                        .status(DEFAULT_SEAT_STATUS)
                        .build())
                .toList();
        showtimeSeatRepository.saveAll(seatSnapshots);
    }

    private BigDecimal calculateSeatPrice(BigDecimal basePrice, BigDecimal multiplier) {
        BigDecimal effectiveMultiplier = multiplier != null ? multiplier : BigDecimal.ONE;
        return basePrice.multiply(effectiveMultiplier).setScale(2, RoundingMode.HALF_UP);
    }

    private List<ScheduleSlot> buildScheduleSlots(Movie movie, ShowtimeRequest request) {
        LocalDateTime baseStart = request.getStartTime();
        if (baseStart == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Start time is required");
        }
        RepeatMode mode = RepeatMode.from(request.getRepeatMode());
        LocalDate repeatUntil = request.getRepeatUntil() != null ? request.getRepeatUntil() : baseStart.toLocalDate();
        if (repeatUntil.isBefore(baseStart.toLocalDate())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Ngày kết thúc phải sau hoặc bằng ngày bắt đầu.");
        }
        List<DayOfWeek> customDays = resolveCustomDays(request.getRepeatDays(), baseStart.getDayOfWeek());
        List<LocalDateTime> startTimes = expandStartTimes(baseStart, repeatUntil, mode, customDays);
        if (startTimes.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Không tìm thấy ngày phù hợp cho tùy chọn đã chọn.");
        }
        List<ScheduleSlot> slots = new ArrayList<>();
        for (LocalDateTime slotStart : startTimes) {
            LocalDateTime slotEnd = calculateEndTime(movie, slotStart, request.getCleanupMinutes());
            slots.add(new ScheduleSlot(slotStart, slotEnd));
        }
        return slots;
    }

    private List<LocalDateTime> expandStartTimes(LocalDateTime start,
                                                 LocalDate repeatUntil,
                                                 RepeatMode mode,
                                                 List<DayOfWeek> customDays) {
        if (mode == RepeatMode.NONE) {
            return List.of(start);
        }
        List<LocalDateTime> result = new ArrayList<>();
        LocalDate currentDate = start.toLocalDate();
        LocalTime startTime = start.toLocalTime();
        while (!currentDate.isAfter(repeatUntil)) {
            DayOfWeek currentDay = currentDate.getDayOfWeek();
            boolean include = switch (mode) {
                case WHOLE_WEEK -> true;
                case WEEKDAY -> isWeekday(currentDay);
                case WEEKEND -> isWeekend(currentDay);
                case CUSTOM -> customDays.contains(currentDay);
                default -> false;
            };
            if (include) {
                result.add(LocalDateTime.of(currentDate, startTime));
            }
            currentDate = currentDate.plusDays(1);
        }
        return result;
    }

    private BigDecimal determineBasePrice(LocalDateTime startTime) {
        LocalDateTime effectiveTime = startTime != null ? startTime : LocalDateTime.now();
        boolean weekend = isWeekend(effectiveTime.getDayOfWeek());
        int hour = effectiveTime.getHour();
        if (hour < 12) {
            return weekend ? WEEKEND_MORNING_PRICE : WEEKDAY_MORNING_PRICE;
        }
        if (hour < 17) {
            return weekend ? WEEKEND_AFTERNOON_PRICE : WEEKDAY_AFTERNOON_PRICE;
        }
        if (hour < 23) {
            return weekend ? WEEKEND_EVENING_PRICE : WEEKDAY_EVENING_PRICE;
        }
        return weekend ? WEEKEND_LATE_PRICE : WEEKDAY_LATE_PRICE;
    }

    private boolean isWeekend(DayOfWeek dayOfWeek) {
        return dayOfWeek == DayOfWeek.SATURDAY
                || dayOfWeek == DayOfWeek.SUNDAY;
    }

    private boolean isWeekday(DayOfWeek dayOfWeek) {
        return !isWeekend(dayOfWeek);
    }

    private enum RepeatMode {
        NONE,
        WHOLE_WEEK,
        WEEKDAY,
        WEEKEND,
        CUSTOM;

        static RepeatMode from(String value) {
            if (value == null || value.isBlank()) {
                return NONE;
            }
            try {
                return RepeatMode.valueOf(value.trim().toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException ex) {
                return NONE;
            }
        }
    }

    private List<DayOfWeek> resolveCustomDays(List<Integer> repeatDays, DayOfWeek fallback) {
        if (repeatDays == null || repeatDays.isEmpty()) {
            return List.of(fallback);
        }
        List<DayOfWeek> resolved = new ArrayList<>();
        for (Integer value : repeatDays) {
            if (value == null) {
                continue;
            }
            if (value >= 1 && value <= 7) {
                DayOfWeek dayOfWeek = DayOfWeek.of(value == 0 ? 7 : value);
                if (!resolved.contains(dayOfWeek)) {
                    resolved.add(dayOfWeek);
                }
            }
        }
        return resolved.isEmpty() ? List.of(fallback) : resolved;
    }

    private record ScheduleSlot(LocalDateTime start, LocalDateTime end) {
    }
}
